#ifndef   __KEY_H__
#define   __KEY_H__

void key_init(void);

#endif

