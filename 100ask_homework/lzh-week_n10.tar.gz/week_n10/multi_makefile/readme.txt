目录：
.
├── add
│   ├── add.c
│   ├── add.h
│   └── Makefile
├── debug
│   ├── bin
│   │   └── app    #可执行文件
│   ├── Makefile
│   └── obj        #汇编文件
│       ├── add.o
│       ├── main.o
│       └── sub.o
├── main.c
├── Makefile
├── readme.txt
└── sub
    ├── Makefile
    ├── sub.c
    └── sub.h


备注：编译成功，请执行该命令进行运行：

#Host:	./debug/app
