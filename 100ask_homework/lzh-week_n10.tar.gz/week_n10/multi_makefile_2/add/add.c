#include<stdio.h>
#include"add.h"

void add(int a, int  b)
{
	int m = 0;
	m = a + b;
	printf("result is %d\n", m);
	return;
}