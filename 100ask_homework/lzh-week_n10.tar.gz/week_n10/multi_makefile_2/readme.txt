目录：
.
├── add
│   ├── add.c
│   ├── add.h
│   └── Makefile
├── main.c
├── Makefile
├── readme.txt
└── sub
    ├── Makefile
    ├── *.o
    ├── sub.c
    └── sub.h

备注：编译成功，请在当前目录下执行该命令进行运行：

#Host: /app
