#include<stdio.h>
#include"sub.h"

void sub(int a, int  b)
{
    int m = 0;
	m = a - b;
	printf("result is %d\n", m);
	return;
}