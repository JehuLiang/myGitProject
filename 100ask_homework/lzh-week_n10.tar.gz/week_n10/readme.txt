1. multi_makefile、multi_makefile_2：两着在编译实现上有点区别，实现功能一样
2. relocate_data：功能部分实现
