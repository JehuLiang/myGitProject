#include<stdio.h>

int main(void)
{
    printf("www.tronlong.com\n");
    return 0;
}